"""Version 1 public search representation: unknown availability is never zero."""
from datetime import datetime, timezone
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from app.availability import filter_rows
from app.cache_schema import MAX_FRESH_AGE_SECONDS, dated_results, timestamp


PUBLIC_QUERY_KEYS = {'bookingresourceid', 'booking_resource_id', 'selecteddate', 'feegroupid',
                     'fee_group_id', 'mobile', 'date', 'holes', 'courseid', 'course', 'players',
                     'weekends', 'ninehole', 'siteid', 'bookingtypeid', 'teedate', 'h', 'd', 'p'}


def public_url(value):
    """Never expose verification responses, holds, session tokens or credentials."""
    if not isinstance(value, str):
        return None
    try:
        parts = urlsplit(value)
        if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password:
            return None
        query = [(k, v) for k, v in parse_qsl(parts.query) if k.lower() in PUBLIC_QUERY_KEYS]
        return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), ''))
    except ValueError:
        return None


def public_snapshot(snapshot):
    """Legacy desktop contract, with token-bearing URLs and raw errors removed."""
    def clean(value, key=''):
        if isinstance(value, dict):
            return {k: clean(v, k) for k, v in value.items()
                    if k.lower() not in {'site', 'recaptcharesponse', 'token', 'cookies', 'headers'}}
        if isinstance(value, list):
            return [clean(v, key) for v in value]
        if key in ('error', 'stale_reason') and value:
            return 'The latest course refresh was unsuccessful.'
        if isinstance(value, str) and (key.endswith('url') or value.startswith(('https://', 'http://'))):
            return public_url(value)
        return value
    return clean(snapshot)


def course_result(course, raw, snapshot, players, low, high, now):
    result = dict(course_id=course['id'], name=course['name'], region=course['region'],
                  status='not_loaded', freshness='unknown', checked_at=None,
                  matching_time_count=None, matching_spots=None, times=[],
                  booking_url=public_url(course['website_url']))
    if raw is None:
        if course['provider'] == 'direct':
            result.update(status='official_link', freshness='not_applicable')
        return result
    weather = raw.get('weather')
    if isinstance(weather, dict) and weather.get('date', snapshot.get('date')) == snapshot.get('date'):
        result['weather'] = {k: v for k, v in weather.items()
                             if k in {'label', 'tmin', 'tmax', 'rain_chance', 'rain_mm', 'wind'}}
        result['weather']['date'] = snapshot.get('date')
    result['booking_url'] = public_url(raw.get('url')) or result['booking_url']
    checked = raw.get('checked_at') or raw.get('stale_since') or snapshot.get('generated_at')
    stamp = timestamp(checked)
    result['checked_at'] = stamp.isoformat() if stamp else None
    age = (now - stamp).total_seconds() if stamp else None
    result['freshness'] = ('unknown' if age is None or age < -60 else
                           'stale' if raw.get('stale') or age >= MAX_FRESH_AGE_SECONDS else 'fresh')
    if raw.get('direct_booking'):
        result.update(status='official_link', freshness='not_applicable')
    elif raw.get('not_configured'):
        result['status'] = 'not_supported'
    elif raw.get('error'):
        result.update(status='unavailable', freshness='unknown')
    elif raw.get('calendar_availability'):
        calendar = raw['calendar_availability']
        result['status'] = {'available': 'verification_required' if raw.get('calendar_captcha_enabled') else 'calendar_available',
                            'full': 'full', 'unreleased': 'unreleased'}.get(calendar, 'unavailable')
        result['calendar_courses'] = raw.get('calendar_courses', [])
    else:
        rows = raw.get('decorated_rows')
        # An absent or malformed row list cannot be interpreted as a full sheet.
        if not isinstance(rows, list):
            result['status'] = 'unavailable'
            return result
        try:
            for row in rows:
                if (not isinstance(row, dict) or isinstance(row.get('spots'), bool)
                        or isinstance(row.get('minutes'), bool)
                        or int(row['spots']) != row['spots'] or int(row['minutes']) != row['minutes']
                        or not 0 <= row['spots'] <= 100 or not 0 <= row['minutes'] < 1440):
                    raise ValueError('Invalid tee-time row')
            matching = filter_rows(rows, players, low, high)
        except (ValueError, KeyError, TypeError, OverflowError):
            result.update(status='unavailable', freshness='unknown')
            return result
        result['times'] = [dict(time=row.get('time'), minutes=row['minutes'], spots=row['spots'],
                               course=row.get('course') or row.get('course_raw'),
                               booking_url=public_url(row.get('source_url')) or result['booking_url'])
                           for row in matching if row['spots'] > 0]
        result.update(status='available' if result['times'] else 'no_matching_times',
                      matching_time_count=len(result['times']),
                      matching_spots=sum(row['spots'] for row in result['times']))
    return result


def search(store, courses, dates, holes, players=None, low=None, high=None, now=None):
    now = now or datetime.now(timezone.utc)
    days = []
    for day in dates:
        snapshot = store.get(day, holes)
        results = {r['site_name']: r for r in dated_results(snapshot)} if snapshot else {}
        items = [course_result(c, results.get(c['name']), snapshot, players, low, high, now) for c in courses]
        fresh = [r for r in items if r['freshness'] == 'fresh' and r['matching_time_count'] is not None]
        days.append(dict(date=day, courses=items, fresh_matching_spots=sum(r['matching_spots'] for r in fresh),
                         exact_fresh_courses=len(fresh), total_courses=len(items)))
    return dict(schema=1, timezone='Australia/Perth', holes=int(holes),
                filters=dict(players=players, from_minutes=low, to_minutes=high), days=days)
