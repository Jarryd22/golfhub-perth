"""Shared lease and cooldown for scheduled/manual availability scans.

Cloud Scheduler is not required. The lease protects the free external timer
and the existing GitHub fallback during a staged migration. No user data here.
"""
from datetime import datetime, timedelta, timezone
from uuid import uuid4

from firebase_admin import firestore

LEASE_SECONDS = 900  # Exceeds the GitHub job's hard 12-minute timeout.
COOLDOWN_SECONDS = 300


def can_start(state, clock):
    until = state.get('lease_until')
    success = state.get('last_success_at')
    if isinstance(until, datetime) and until > clock:
        return False
    return not (isinstance(success, datetime) and
                clock - success < timedelta(seconds=COOLDOWN_SECONDS))


def acquire(db, clock=None):
    clock = clock or datetime.now(timezone.utc)
    ref = db.collection('checkerControl').document('availability')
    owner = uuid4().hex

    @firestore.transactional
    def claim(tx):
        current = ref.get(transaction=tx)
        state = current.to_dict() if current.exists else {}
        if not can_start(state, clock):
            return None
        tx.set(ref, {'owner': owner, 'last_started_at': clock,
                     'lease_until': clock + timedelta(seconds=LEASE_SECONDS)}, merge=True)
        return owner
    return claim(db.transaction())


def finish(db, owner, success, clock=None):
    clock = clock or datetime.now(timezone.utc)
    ref = db.collection('checkerControl').document('availability')

    @firestore.transactional
    def release(tx):
        current = ref.get(transaction=tx)
        if not current.exists or current.to_dict().get('owner') != owner:
            return False
        tx.set(ref, {'owner': '', 'lease_until': clock,
                     'last_success_at' if success else 'last_failure_at': clock}, merge=True)
        return True
    return release(db.transaction())
