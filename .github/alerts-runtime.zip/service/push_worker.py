"""One bounded GitHub checker run; Firebase ADC/OIDC only, no private key in code.

Provider reads are shared across watches. Firestore transactions persist quiet
baselines and an outbox together. Delivery rechecks the watch and fresh matches.
FCM is at-least-once: a stable Android notification tag collapses crash retries.
"""
import argparse
import hashlib
import json
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone

import firebase_admin
from firebase_admin import firestore, messaging

from app.cache_schema import make_snapshot
from app.golfhub_core import DATA_DIR, CONFIG_FILE, load_sites, fetch_site_result, preload_weather_cache
from service.catalog import Catalog
from service.search import course_result
from service.push_logic import validate_watch, generation, transition, event_id, slot_key, valid_matches

PROJECT = 'golfhub-perth'


def now():
    return datetime.now(timezone.utc)


def send(devices, *, title, body, data, tag):
    delivered = 0
    for device in devices:
        value = device.to_dict()
        if not value.get('enabled') or not value.get('token'):
            continue
        try:
            messaging.send(messaging.Message(token=value['token'],
                notification=messaging.Notification(title=title, body=body), data=data,
                android=messaging.AndroidConfig(priority='high', ttl=timedelta(minutes=10),
                    notification=messaging.AndroidNotification(channel_id='tee_time_alerts',
                        icon='notification_golf', tag=tag))))
            delivered += 1
        except messaging.UnregisteredError:
            device.reference.update({'enabled': False})
        except Exception:
            # Never print a registration token or private watch document.
            logging.warning('A notification could not be delivered; it can be retried.')
    return delivered


def phone_tests(db):
    for doc in db.collection_group('pushTests').limit(100).stream():
        if len(doc.reference.path.split('/')) != 4 or not doc.reference.path.startswith('users/'):
            continue
        value = doc.to_dict()
        created = value.get('created_at')
        if not isinstance(created, datetime) or not timedelta(0) <= now()-created < timedelta(hours=1):
            doc.reference.delete()
            continue
        user = doc.reference.parent.parent
        device = user.collection('devices').document(doc.id).get()
        if device.exists:
            identifier = hashlib.sha256((doc.reference.path+str(created)).encode()).hexdigest()[:32]
            count = send([device], title='GolfHub server test',
                body='This notification travelled from the GitHub checker to your phone.',
                data={'kind':'test', 'event_id':identifier}, tag=identifier)
            if count:
                # Delete only this request, not a newer test queued while sending.
                @firestore.transactional
                def acknowledge(tx):
                    latest = doc.reference.get(transaction=tx)
                    if latest.exists and latest.to_dict().get('created_at') == created:
                        tx.delete(doc.reference)
                acknowledge(db.transaction())
                print('Server test accepted by FCM.')


def collect(specs, catalog):
    by_name={s.name:s for s in load_sites(DATA_DIR/CONFIG_FILE)}
    requests=sorted({(day,spec['holes'],cid) for spec in specs for day in spec['dates'] for cid in spec['course_ids']})
    if len(requests)>160:
        raise RuntimeError('Private test checker limit reached: reduce watched courses/dates before enabling more alerts.')
    # Weather is supplied by the main cache; alert scans do not need another forecast request.
    preload_weather_cache({s.weather_query:{} for s in by_name.values() if s.weather_query})
    result={}
    def fetch(key):
        day,holes,cid=key
        site=by_name[catalog.courses[cid]['name']]
        if site.provider=='direct':
            return dict(site_name=site.name, direct_booking=True)
        observed=fetch_site_result(site,day,str(holes),None,None,None)
        observed['checked_at']=now().isoformat()
        return observed
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(fetch,key):key for key in requests}
        for future in as_completed(futures):
            key=futures[future]
            try: result[key]=future.result()
            except Exception: result[key]=dict(site_name=catalog.courses[key[2]]['name'],error='Refresh failed')
    return result


def rows_for(spec, raw, catalog, clock):
    rows=[]
    for day in spec['dates']:
        for cid in spec['course_ids']:
            observed=raw[(day,spec['holes'],cid)]
            # Actual collector checked_at must be preserved, never freshened at delivery.
            snapshot=make_snapshot(day,str(spec['holes']),[observed])
            row=course_result(catalog.courses[cid],observed,snapshot,spec['players'],
                spec['from_minutes'],spec['to_minutes'],clock)
            rows.append((day,cid,row))
    return rows


def evaluate(db, doc, spec, raw, catalog):
    clock=now()
    gen=generation(doc.to_dict())
    user=doc.reference.parent.parent
    state_id=hashlib.sha256((doc.reference.path+gen).encode()).hexdigest()
    root=db.collection('alertState').document(state_id)
    rows=rows_for(spec,raw,catalog,clock)
    @firestore.transactional
    def commit(tx):
        latest=doc.reference.get(transaction=tx)
        if not latest.exists or generation(latest.to_dict())!=gen:
            return
        refs=[root.collection('observations').document(day+'_'+cid) for day,cid,_ in rows]
        previous=[ref.get(transaction=tx) for ref in refs]
        changed=[]; matches=[]; fresh=0
        for (day,cid,row),ref,old in zip(rows,refs,previous):
            before=old.to_dict() if old.exists else None
            after,new=transition(before,row,day,clock)
            if valid_matches(row,day,clock) is not None: fresh+=1
            if after != before: changed.append((ref,after))
            for tee in new:
                matches.append(dict(date=day,course_id=cid,course_name=catalog.courses[cid]['name'],**tee))
        for ref,after in changed: tx.set(ref,after)
        for day,cid,row in rows:
            tx.set(user.collection('watchResults').document(doc.id).collection('days').document(day).collection('courses').document(cid),
                   {'watch_created_at':doc.to_dict()['created_at'],'result':row})
        tx.set(root,{'watch_path':doc.reference.path,'generation':gen,'expires_at':max(spec['dates']) if spec['dates'] else '',
                     'updated_at':clock})
        tx.set(user.collection('watchStatus').document(doc.id),{'last_checked_at':clock,'fresh_courses':fresh,
                     'total_course_dates':len(rows),'state':'monitoring' if spec['dates'] else 'expired'})
        if matches:
            identifier=event_id(doc.reference.path,gen,matches)
            tx.set(db.collection('alertOutbox').document(identifier),{'watch_path':doc.reference.path,'generation':gen,
                'created_at':clock,'matches':matches,'players':spec['players'],'holes':spec['holes']})
    commit(db.transaction())


def deliver(db, raw, catalog):
    for event in db.collection('alertOutbox').limit(100).stream():
        value=event.to_dict(); clock=now()
        doc=db.document(value['watch_path']).get()
        if (not doc.exists or generation(doc.to_dict())!=value['generation']
            or clock-value['created_at']>=timedelta(minutes=10)):
            event.reference.delete(); continue
        try: spec=validate_watch(doc.to_dict(),catalog,clock)
        except (ValueError,KeyError,TypeError): event.reference.delete(); continue
        valid=[]
        for match in value['matches']:
            key=(match['date'],spec['holes'],match['course_id'])
            if key not in raw: continue
            row=course_result(catalog.courses[key[2]],raw[key],make_snapshot(key[0],str(key[1]),[raw[key]]),
                spec['players'],spec['from_minutes'],spec['to_minutes'],clock)
            available=valid_matches(row,key[0],clock)
            if available is not None and any(slot_key(t)==slot_key(match) for t in available): valid.append(match)
        if not valid:
            event.reference.delete(); continue
        # Final read closes the large collection/sending gap when an alert was paused.
        latest=doc.reference.get()
        if not latest.exists or generation(latest.to_dict())!=value['generation']:
            event.reference.delete(); continue
        first=valid[0]
        devices=list(doc.reference.parent.parent.collection('devices').stream())
        count=send(devices,title=f"{len(valid)} new matching tee {'time' if len(valid)==1 else 'times'}",
            body=f"{first['course_name']} · {first['date']} · {first['time']} · {spec['players']} players. Check before booking.",
            data={'event_id':event.id,'watch_id':doc.id,'date':first['date'],'course_id':first['course_id']},tag=event.id)
        if count: event.reference.delete()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--tests-only',action='store_true')
    args=parser.parse_args()
    firebase_admin.initialize_app(options={'projectId':PROJECT})
    db=firestore.client()
    phone_tests(db)
    if args.tests_only: return
    catalog=Catalog(); watches=[]; per_user={}
    for doc in db.collection_group('watches').limit(101).stream():
        if len(doc.reference.path.split('/'))!=4 or not doc.reference.path.startswith('users/'): continue
        user=doc.reference.parent.parent.path
        per_user[user]=per_user.get(user,0)+1
        if per_user[user]>10: continue
        try:
            spec=validate_watch(doc.to_dict(),catalog,now())
            if spec['dates']: watches.append((doc,spec))
        except (ValueError,TypeError,KeyError):
            logging.warning('An invalid or disabled watch was skipped.')
    if len(watches)>100: raise RuntimeError('Private test watch limit reached')
    raw=collect([spec for _,spec in watches],catalog)
    for doc,spec in watches: evaluate(db,doc,spec,raw,catalog)
    deliver(db,raw,catalog)
    print(f'Checked {len(watches)} watches using {len(raw)} shared course/date observations.')


if __name__=='__main__': main()
