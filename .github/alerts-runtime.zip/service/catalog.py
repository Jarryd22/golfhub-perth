"""Stable identifiers and portable course metadata for all clients."""
import json
from pathlib import Path

DATA = Path(__file__).resolve().parents[1] / 'data'


class Catalog:
    def __init__(self, root=DATA):
        self.root = Path(root)
        config = json.loads((self.root / 'courses.json').read_text(encoding='utf-8'))
        ids = json.loads((self.root / 'course_ids.json').read_text(encoding='utf-8'))
        locations = json.loads((self.root / 'course_locations.json').read_text(encoding='utf-8'))['courses']
        self.profiles = json.loads((self.root / 'course_profiles.json').read_text(encoding='utf-8'))
        self.courses = {}
        for site in config.get('sites', config.get('courses', [])):
            name = site['name']
            identifier = ids[name]
            if identifier in self.courses:
                raise ValueError('Duplicate course identifier')
            location = locations.get(name, {})
            self.courses[identifier] = dict(id=identifier, name=name, region=site.get('region', 'Other'),
                holes=sorted(int(h) for h in site['holes']), provider=site.get('provider', 'miclub'),
                website_url=site.get('info_url') or 'https://' + site['domain'],
                location={key: location.get(key) for key in ('lat', 'lon', 'kind', 'source')})
        if not self.courses:
            raise ValueError('Empty course catalog')

    def profile(self, identifier):
        def portable(value):
            if isinstance(value, dict):
                return {k: portable(v) for k, v in value.items()}
            if isinstance(value, list):
                return [portable(v) for v in value]
            if isinstance(value, str) and value.startswith('course_guides/'):
                return '/v1/course-assets/' + value.removeprefix('course_guides/')
            return value
        return portable(self.profiles.get(self.courses[identifier]['name'], {}))
