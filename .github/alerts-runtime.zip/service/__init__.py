"""GolfHub shared availability service; independent of Qt and Windows."""
