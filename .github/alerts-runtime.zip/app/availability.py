"""UI-independent tee-time matching, shared by Windows and the service."""


def filter_rows(rows, players=None, low=None, high=None):
    filtered = list(rows or [])
    if players is not None:
        filtered = [r for r in filtered if int(r.get('spots', 0) or 0) >= players]
    if low is not None:
        filtered = [r for r in filtered if int(r.get('minutes', 0) or 0) >= low]
    if high is not None:
        filtered = [r for r in filtered if int(r.get('minutes', 0) or 0) <= high]
    return filtered
