"""Portable snapshot contract shared by collectors, desktop and the HTTP service."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

CACHE_SCHEMA = 1
MAX_FRESH_AGE_SECONDS = 15 * 60


def serialise_result(result: dict[str, Any]) -> dict[str, Any]:
    """Remove runtime-only values (notably the Site dataclass)."""
    clean = {key: value for key, value in result.items() if key != "site"}
    return json.loads(json.dumps(clean, ensure_ascii=False, default=str))


def make_snapshot(date_str: str, hole_type: str, results: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "schema": CACHE_SCHEMA,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "date": date_str,
        "holes": hole_type,
        "results": [serialise_result(result) for result in results],
    }


def validate_snapshot(payload: Any, date_str: str, hole_type: str) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("Cache response is not an object")
    if payload.get("schema") != CACHE_SCHEMA:
        raise ValueError("Unsupported cache schema")
    if payload.get("date") != date_str or str(payload.get("holes")) != str(hole_type):
        raise ValueError("Cache response does not match the requested search")
    if not isinstance(payload.get("results"), list):
        raise ValueError("Cache response has no results list")
    for result in payload['results']:
        if not isinstance(result, dict) or not isinstance(result.get('site_name'), str):
            raise ValueError('Cache contains an invalid course result')
        if not isinstance(result.get('decorated_rows', []), list):
            raise ValueError('Cache contains invalid tee-time rows')
    return payload


def timestamp(value):
    try:
        stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
        return stamp.astimezone(timezone.utc) if stamp.tzinfo else None
    except (AttributeError, TypeError, ValueError):
        return None


def dated_results(payload):
    """Carry the actual observation time through partial cache merges."""
    return [dict(result, checked_at=(result.get('checked_at') or
            result.get('stale_since') or payload.get('generated_at')))
            for result in payload.get('results', [])]


def result_needs_refresh(result, now=None):
    if result.get('direct_booking'):
        return False
    stamp = timestamp(result.get('checked_at'))
    age = ((now or datetime.now(timezone.utc)) - stamp).total_seconds() if stamp else None
    return bool(result.get('stale') or result.get('error') or age is None
                or age < -60 or age >= MAX_FRESH_AGE_SECONDS)


def merge_snapshots(previous, incoming):
    """Merge per course; a failed/newly published cache must not erase good data."""
    if not previous or (previous.get('date'), str(previous.get('holes'))) != (
            incoming.get('date'), str(incoming.get('holes'))):
        return dict(incoming, results=dated_results(incoming))
    merged = {r['site_name']: r for r in dated_results(previous)}
    for fresh in dated_results(incoming):
        name = fresh['site_name']
        prior = merged.get(name)
        if prior:
            old_time = timestamp(prior.get('checked_at'))
            new_time = timestamp(fresh.get('checked_at'))
            if fresh.get('error') and not prior.get('error'):
                fresh = dict(prior, stale=True, stale_reason=str(fresh['error']),
                             last_refresh_attempt_at=incoming.get('generated_at'))
            elif old_time and (not new_time or old_time > new_time):
                continue
        merged[name] = fresh
    return dict(incoming, results=list(merged.values()))

